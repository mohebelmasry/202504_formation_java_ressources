## Versionning :
- https://semver.org/lang/fr/

## Spring : 
- https://roadmap.sh/spring-boot
- https://www.rameshfadatare.com/cheat-sheet/spring-and-spring-boot-annotations-cheat-sheet/
- https://www.jrebel.com/sites/rebel/files/pdfs/cheatsheet-jrebel-spring-annotations.pdf
- https://spring.io/guides
- https://www.baeldung.com/rest-http-put-vs-post


# https://github.com/sauvageb/Digicomp_Session_2

# Intellij IDEA Community Edition (Java 17 + Maven)

# XAMPP (Base de donnees MySQL + PhpMyAdmin)

# Git et Git Bash

# Postman ou Bruno

# draw.io (Diagrammes UML)
