package exercices.date;

/*
 ** Consigne **
 *
 * Vérifier si la date de l'événement périodique est arrivé
 * Date 1 : la date de votre anniversaire
 * Date 2 : la date du jour
 *
 * Affichez un message pour indiquer si c'est votre anniversaire ou non.
 *
 * ASTUCE : Vous pouvez utiliser L'objet MonthDay
 *
 *************
 *
 * Resultat attendu :
 */
class Exo5 {

    public static void main(String[] args) {
//        Object date1 = ;
//        Object date2 = ;
//        MonthDay birthday;

//        if(currentMonthDay ... birthday){
        System.out.println("C'est votre anniversaire");
//        }else {
        System.out.println("Votre anniversaire n'est pas encore arrivé");
//        }
    }


}
