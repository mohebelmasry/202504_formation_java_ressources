package fr.sauvageboris.training.exercice8.model;

public interface PaleFace {

    void beScalped();

}
