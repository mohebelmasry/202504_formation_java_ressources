package fr.sauvageboris.training.exercice10.exo5_IP;

public class ExceptionAdrIP extends Exception {

    public ExceptionAdrIP(String message) {
        super(message);
    }
}
