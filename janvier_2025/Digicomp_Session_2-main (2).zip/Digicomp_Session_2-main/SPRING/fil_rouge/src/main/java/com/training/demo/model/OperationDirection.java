package com.training.demo.model;

public enum OperationDirection {
    INCOMING,
    OUTCOMING
}
